module.exports = {
	isAuth: require('./auth.middleware'),
};
